<?php
    require_once __DIR__ . "/../repository/DBAccess.php";

    class UserService {
        public static function getAllUsers()
        {
            $db = new DBAccess("users");
            $result = $db->getAll();
            return $result;
        }
        public static function createNewUser($input) {
            $db = new DBAccess("users");
            $result = $db->findByEmail($input["email"]);
            if($result !== null) {
                return ["error" => "User already exists"];
            } else {
                $data = [
                    "id" => uniqid(),
                    "email" => $input["email"],
                    "pwd" => $input["pwd"],
                    "name" => $input["name"]
                ];
                $result = $db->postData($data);
                return $result;
            }

            
        }
        public static function getSpecUser($id) {
            $db = new DBAccess("users");
            $result = $db->findById($id);
            if($result === null) {
                return ["error" => "User not found"];
            } else {
                return $result;
            }
            
        }

        public static function changeUser($id, $data) {
            $db = new DBAccess("users");
            $result = $db->findById($id);
            if($result === null) {
                return ["error" => "User not found"];
            } else {
                $newData = array_filter($data, function ($value) {
                    return $value !== null;
                });
                $result = $db->patchData($id, $newData);
                return $result;
            }
        }

        public static function deleteUser($id, $data) {
            $db = new DBAccess("users");
            $result = $db->findById($id);
            if ($result === null) {
                return ["error" => "User not found"];
            }
            if ($result["email"] === $data["email"] && $result["pwd"] === $data["pwd"]) {
                $deleteResult = $db->deleteData($id);
                return ["message" => "User succesfully deleted"];
            }
            return ["error" => "Invalid email or password"];
        }
        
    }


?>

