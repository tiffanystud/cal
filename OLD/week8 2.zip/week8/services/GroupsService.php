<?php

require_once __DIR__ . "/../repository/DBAccess.php";

class GroupsService
{


    /* ---- GET ---- */
    public static function getAll()
    {

        // Hämtar db för bara groups, conatructorn sätter resource till ex: "groups"
        $db = new DBAccess("groups");
        $groups = $db->getAll();

        if (empty($groups)) {
            throw new Exception("No groups found");
        }

        return $groups;

    }

    public static function getById($id)
    {
        // Hämtar db för bara groups, conatructorn sätter resource till ex: "groups"
        $db = new DBAccess("groups");
        $group = $db->findById($id);

        if (!$group) {
            throw new Exception("Group not found");
        }

        return $group;
    }
    public static function getByName($name)
    {
        // Hämtar db för bara groups, conatructorn sätter resource till ex: "groups"
        $db = new DBAccess("groups");
        $group = $db->findById($name);

        if (!$group) {
            throw new Exception("Group not found");
        }

        return $group;
    }



    /* --- POST ---- */
    public static function createGroup($input)
    {

        if (!isset($input["name"])) {
            throw new Exception(message: "Group must have a name");
        }

        $db = new DBAccess("groups");

        $newGroup = [
            "id" => uniqid(),
            "name" => $input["name"]
        ];

        return $db->postData($newGroup);
    }

    /* --- PATCH ---- */
    public static function updateGroup($input){
        
        // Id and name needed for patch
        if (!isset($input["id"])) {
            throw new Exception("Id missing");
        }
        if (!isset($input["name"])) {
            throw new Exception("Name missing");
        }
        
        $db = new DBAccess("groups");

        return $db->patchData($input["id"], ["name" => $input["name"]]);
            
    }


    /* --- DELETE ---- */
    public static function deleteGroup($input)
    {

        $db = new DBAccess("groups");

        if (!isset($input["id"])) {
            throw new Exception("Id missing");
        }
        $id = $input["id"];

        return $db->deleteData($id);

    }





}